import menu
import fltk

fltk.cree_fenetre(800,800, redimension=True)
menu.menu()